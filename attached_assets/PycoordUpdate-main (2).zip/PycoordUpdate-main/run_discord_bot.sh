#!/bin/bash
# Run the Discord bot
export PYTHONPATH="$PWD"
python bot.py