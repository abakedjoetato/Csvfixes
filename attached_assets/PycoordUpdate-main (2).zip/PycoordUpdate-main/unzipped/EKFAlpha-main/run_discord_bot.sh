#!/bin/bash
# Launch the Discord bot
python run_discord_on_replit.py
