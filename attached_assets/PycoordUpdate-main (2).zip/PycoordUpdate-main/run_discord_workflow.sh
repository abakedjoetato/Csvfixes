#!/bin/bash
echo "Starting EKFAlpha Discord Bot..."
python main.py